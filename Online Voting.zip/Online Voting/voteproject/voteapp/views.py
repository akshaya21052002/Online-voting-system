from django.shortcuts import render,redirect
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .models import CustomUser , Candidate, Vote, Election
from datetime import date
from django.core.mail import send_mail
from django.db.models import Count
from django.conf import settings
from django.utils import timezone
from django.db import IntegrityError
import random

from datetime import datetime

# Create your views here.
def home(request):
    return render(request, 'home.html')



def register(request):
    if request.method == "POST":
        username=request.POST.get("username")
        email=request.POST.get("email")
        password=request.POST.get("password")
        dob=request.POST.get("date_of_birth")
        gender=request.POST.get("gender")

        dob = date.fromisoformat(dob)

        today=date.today()
        age=today.year - dob.year - ((today.month, today.day)< (dob.month, dob.day))

        if CustomUser.objects.filter(username=username).exists():
            messages.error(request,"Username already exists!")
            return redirect("register")


        if CustomUser.objects.filter(email=email).exists():
            messages.error(request,"Email already registered!")
            return redirect("register")

        if age < 18:
            messages.error(request, "You are under 18, you can't register.")
            return redirect("register") 

        CustomUser.objects.create_user(
            username=username,
            email=email,
            password=password,
            date_of_birth=dob,
            gender=gender

        )
        messages.success(request, "Account created successfully!")
        return redirect("register")
    
    return render(request, "register.html")




#login
def user_login(request):
    if request.method == "POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        
        user=authenticate(request, username=username,password=password)

        if user is not None:
            otp=random.randint(1000,9999)

            request.session['otp']=otp
            request.session['user_id']=user.id 
            request.session['otp_time']=datetime.now().timestamp()

            send_mail(
                "Voting system OTP",
                f"Your OTP is {otp}",
                settings.EMAIL_HOST_USER,
                [user.email],
                fail_silently=False,
            )
            return redirect("otp")
        else:
            messages.error(request, "Invalid username or password")
        
    return render(request, 'login.html')    





def verify_otp(request):
    if request.method == "POST":

        entered_otp=request.POST.get("otp")
        session_otp=request.session.get("otp")
        otp_time=request.session.get("otp_time")

        if otp_time:
            current_time=datetime.now().timestamp()
            if current_time - otp_time > 300:
                return render(request, "otp.html", {"error":"OTP expired! login again"}) 
        
        if str(entered_otp) == str(session_otp):
            return redirect("vote")
        
        else:
            return render(request, "otp.html", {"error":"Invalid OTP!"})

    return render(request, "otp.html")





def vote(request):

    election = Election.objects.first()
    candidates = Candidate.objects.filter(election=election)

    now = timezone.now()

    # BEFORE ELECTION
    if now < election.start_time:
        return render(request, "vote.html", {
            "message": "Voting has not started yet",
            "election": election
        })

    # DURING ELECTION
    elif election.start_time <= now <= election.end_time:
        return render(request, "vote.html", {
            "candidates": candidates,
            "election": election
        })

    # AFTER ELECTION
    else:
        return redirect("result")
    



def cast_vote(request, candidate_id):

    candidate = get_object_or_404(Candidate, id=candidate_id)

    user_id = request.session.get("user_id")
    user = CustomUser.objects.get(id=user_id)

    try:
        Vote.objects.create(
            user=user,
            candidate=candidate,
            election=candidate.election
        )
        return render(request, "success.html", {"message": "Vote cast successfully!"})

    except IntegrityError:
        return render(request, "success.html", {"message": "You have already voted!"})





def result(request):
    
    election = Election.objects.first()
    now = timezone.now()

    # If election is still running
    if now < election.end_time:
        return render(request, "result.html", {
            "message": "Results will be available after the election ends."
        })

    # After election ends
    candidates = Candidate.objects.annotate(
        total_votes=Count('vote')
    ).order_by('-total_votes')

    winner = candidates.first()

    return render(request, "result.html", {
        "candidates": candidates,
        "winner": winner
    })
