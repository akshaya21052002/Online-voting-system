from django.contrib import admin
from .models import CustomUser, Election, Candidate, Vote, OTP

# Register your models here.
admin.site.register(CustomUser)
admin.site.register(Election)
admin.site.register(Candidate)
admin.site.register(Vote)
admin.site.register(OTP)
