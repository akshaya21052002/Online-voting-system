from django.urls import path
from . import views

urlpatterns=[
    path('', views.home, name='home'),
    path("register/",views.register,name="register"),
    path('login/',views.user_login, name='login'),
    path('verify_otp/', views.verify_otp, name="otp"),
    path('vote', views.vote, name="vote"),
    path('vote/<int:candidate_id>/', views.cast_vote, name='cast_vote'),
    path('result/', views.result, name='result'),
]