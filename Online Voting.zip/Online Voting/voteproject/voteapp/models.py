from django.db import models
from datetime import date
from django.contrib.auth.models import AbstractUser


#user account creation
class CustomUser(AbstractUser):
    gender_choices=(
        ('Male','Male'),
        ('Female','Female'),
        ('Others','Others'),
    )
    email=models.EmailField(unique=True)
    date_of_birth=models.DateField(null=True, blank=True)
    gender=models.CharField(max_length=10,choices=gender_choices,null=True,blank=True)
    face_image=models.ImageField(upload_to='',null=True,blank=True)
    is_verified=models.BooleanField(default=False)    

    
    def calculate_age(self):
        today=date.today()
        age=today.year - self.date_of_birth.year - ((today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day) )
        return age
    
    def save(self, *args, **kwargs):
        if self.date_of_birth:
            if self.calculate_age() < 18:
                raise ValueError("User is under 18 you can not register.❌")
        super().save(*args, **kwargs)

    def __str__(self):
        return self.username



#about election 
class Election(models.Model):
    name=models.CharField(max_length=150)
    start_time=models.DateTimeField()
    end_time=models.DateTimeField()

    def __str__(self):
        return self.name


#candidate details
class Candidate(models.Model):
    election=models.ForeignKey('Election', on_delete=models.CASCADE)
    name=models.CharField(max_length=50)
    party=models.CharField(max_length=150)
    photo=models.ImageField(upload_to='candidates/')
    votes = models.IntegerField(default=0)

    def __str__(self):
        return self.name
    

#voting system
class Vote(models.Model):
    user=models.ForeignKey('CustomUser', on_delete=models.CASCADE)
    candidate=models.ForeignKey('Candidate',on_delete=models.CASCADE)
    election=models.ForeignKey('Election', on_delete=models.CASCADE)

    class Meta:
        unique_together=('user','election')

    def __str__(self):
        return f"{self.user} voted for {self.candidate}"


#otp
class OTP(models.Model):
    user=models.ForeignKey('CustomUser', on_delete=models.CASCADE)
    otp_code=models.CharField(max_length=6)
    created_at=models.DateTimeField(auto_now_add=True)
    is_used=models.BooleanField(default=False)

    def __str__(self):
        return f"otp for {self.user.username}"


    
    
